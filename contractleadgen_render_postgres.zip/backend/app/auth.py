
import os, datetime
from jose import jwt, JWTError

JWT_SECRET = os.environ.get('JWT_SECRET', 'change-me')
def create_admin_token():
    payload = {'role':'admin', 'iat': int(datetime.datetime.utcnow().timestamp())}
    token = jwt.encode(payload, JWT_SECRET, algorithm='HS256')
    return token

def verify_admin_jwt(token: str):
    try:
        data = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
        if data.get('role') != 'admin':
            raise Exception('invalid role')
        return True
    except JWTError:
        raise

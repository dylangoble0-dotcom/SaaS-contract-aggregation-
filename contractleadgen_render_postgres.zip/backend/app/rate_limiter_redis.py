
import os, time
try:
    import redis
except Exception:
    redis = None
from fastapi import HTTPException

REDIS_URL = os.environ.get('REDIS_URL')
RATE = int(os.environ.get('RATE_LIMIT', '60'))
WINDOW = int(os.environ.get('RATE_WINDOW', '60'))

if REDIS_URL and redis:
    r = redis.from_url(REDIS_URL, decode_responses=True)
else:
    r = None
    BUCKETS = {}

def check_rate(label: str):
    if not label:
        return
    if r:
        key = f"rl:{label}"
        now = int(time.time())
        count = r.get(key)
        if count is None:
            r.set(key, 1, ex=WINDOW)
        else:
            count = int(count)
            if count >= RATE:
                raise HTTPException(status_code=429, detail='Rate limit exceeded')
            r.incr(key)
    else:
        # in-memory fixed-window (demo only)
        now = int(time.time())
        bucket = BUCKETS.get(label, {'ts': now, 'count': 0})
        if now - bucket['ts'] > WINDOW:
            bucket = {'ts': now, 'count': 0}
        if bucket['count'] >= RATE:
            BUCKETS[label] = bucket
            raise HTTPException(status_code=429, detail='Rate limit exceeded')
        bucket['count'] += 1
        BUCKETS[label] = bucket

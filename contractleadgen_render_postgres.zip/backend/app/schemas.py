
from pydantic import BaseModel, EmailStr
from typing import Optional
import datetime

class ProjectCreate(BaseModel):
    title: str
    description: Optional[str] = ""

class ProjectOut(BaseModel):
    id: int
    title: str
    description: Optional[str]
    posted_at: datetime.datetime
    class Config:
        orm_mode = True

class BidCreate(BaseModel):
    project_id: int
    bidder: str
    amount: float
    notes: Optional[str] = ""

class BidOut(BaseModel):
    id: int
    project_id: int
    bidder: str
    amount: float
    notes: Optional[str]
    class Config:
        orm_mode = True

class RegisterIn(BaseModel):
    email: EmailStr

class ApiKeyOut(BaseModel):
    key: str
    label: Optional[str] = None
    created_at: datetime.datetime

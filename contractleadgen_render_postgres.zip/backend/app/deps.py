
from fastapi import Header, HTTPException, Depends
from .db import SessionLocal
from .models import ApiKey
from sqlalchemy.orm import Session

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_api_key(x_api_key: str = Header(None), db: Session = Depends(get_db)):
    if not x_api_key:
        raise HTTPException(status_code=401, detail="Missing X-API-KEY header")
    from .utils import hash_key
    key_hash = hash_key(x_api_key)
    ak = db.query(ApiKey).filter(ApiKey.key_hash==key_hash, ApiKey.revoked==False).first()
    if not ak:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return ak

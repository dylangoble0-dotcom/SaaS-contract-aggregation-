
from fastapi import FastAPI, Depends, HTTPException, Header, Request
from .db import Base, engine
from . import models, schemas, utils
from .deps import get_db, get_api_key
from .rate_limiter_redis import check_rate
import datetime, os
from sqlalchemy.orm import Session
import stripe

app = FastAPI(title="ContractLeadGen API")
Base.metadata.create_all(bind=engine)

stripe.api_key = os.environ.get('STRIPE_SECRET', '')

@app.get('/health')
def health():
    return {'status':'ok', 'time': datetime.datetime.utcnow().isoformat()}

@app.post('/admin/token')
async def admin_token(request: Request):
    body = await request.json()
    admin_secret = os.environ.get('ADMIN_TOKEN')
    if not admin_secret:
        raise HTTPException(status_code=500, detail='Admin token not configured')
    provided = body.get('admin_token')
    if provided != admin_secret:
        raise HTTPException(status_code=401, detail='Invalid admin token')
    from .auth import create_admin_token
    return {'jwt': create_admin_token()}

@app.post('/register', response_model=schemas.ApiKeyOut)
def register(payload: schemas.RegisterIn, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email==payload.email).first()
    if not user:
        user = models.User(email=payload.email)
        db.add(user)
        db.commit()
        db.refresh(user)
    raw = utils.generate_api_key()
    kh = utils.hash_key(raw)
    ak = models.ApiKey(key_hash=kh, label='default', user_id=user.id)
    db.add(ak)
    db.commit()
    db.refresh(ak)
    return {'key': raw, 'label': ak.label, 'created_at': ak.created_at}

@app.post('/projects', response_model=list[schemas.ProjectOut])
def create_project(p: schemas.ProjectCreate, db: Session = Depends(get_db)):
    proj = models.Project(title=p.title, description=p.description)
    db.add(proj)
    db.commit()
    db.refresh(proj)
    return proj

@app.get('/projects', response_model=list[schemas.ProjectOut])
def list_projects(db: Session = Depends(get_db)):
    return db.query(models.Project).order_by(models.Project.posted_at.desc()).all()

@app.post('/projects/{project_id}/bids', response_model=schemas.BidOut)
def create_bid(project_id: int, b: schemas.BidCreate, db: Session = Depends(get_db)):
    proj = db.query(models.Project).filter(models.Project.id==project_id).first()
    if not proj:
        raise HTTPException(status_code=404, detail='Project not found')
    bid = models.Bid(project_id=project_id, bidder=b.bidder, amount=b.amount, notes=b.notes)
    db.add(bid)
    db.commit()
    db.refresh(bid)
    return bid

@app.get('/projects/{project_id}/bids', response_model=list[schemas.BidOut])
def list_bids(project_id: int, db: Session = Depends(get_db)):
    return db.query(models.Bid).filter(models.Bid.project_id==project_id).all()

@app.post('/leads/generate')
def generate_lead(project: schemas.ProjectCreate, api_key = Depends(get_api_key), db: Session = Depends(get_db)):
    check_rate(api_key.label)
    proj = models.Project(title=project.title, description=project.description)
    db.add(proj)
    db.commit()
    db.refresh(proj)
    base = 1000.0
    multiplier = 1 + (len(proj.description) / 2000.0)
    suggestion = round(base * multiplier, 2)
    return {'project_id': proj.id, 'suggested_bid': suggestion, 'api_key_label': api_key.label}

@app.get('/admin/api-keys')
def list_api_keys(db: Session = Depends(get_db), x_admin_jwt: str = Header(None)):
    from .auth import verify_admin_jwt
    if not x_admin_jwt:
        raise HTTPException(status_code=401, detail='Missing admin jwt header')
    verify_admin_jwt(x_admin_jwt)
    keys = db.query(models.ApiKey).all()
    return [{'id': k.id, 'label': k.label, 'revoked': k.revoked, 'user_id': k.user_id, 'created_at': k.created_at.isoformat()} for k in keys]

@app.post('/create-checkout-session')
def create_checkout():
    # Create Stripe Checkout session server-side: (placeholder)
    return {'message':'create-checkout-session placeholder — integrate Stripe SDK and create a session'}

@app.post('/stripe-webhook')
async def stripe_webhook(request: Request):
    payload = await request.body()
    sig = request.headers.get('stripe-signature')
    # TODO: verify signature with stripe.Webhook.construct_event
    return {'received': True}

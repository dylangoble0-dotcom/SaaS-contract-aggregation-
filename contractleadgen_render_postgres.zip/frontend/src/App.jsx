import React from 'react'
import Hero from './components/Hero'
import Features from './components/Features'
import Footer from './components/Footer'
import DashboardPreview from './components/DashboardPreview'
import AnimatedBackground from './components/AnimatedBackground'

export default function App(){
  return (
    <div className="min-h-screen bg-cream-50 text-gray-900">
      <header className="max-w-6xl mx-auto p-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-md" style={background: '#004830'}></div>
          <h1 className="text-xl font-semibold">ContractLeadGen</h1>
        </div>
        <nav className="space-x-4">
          <a href="#features" className="text-sm">Features</a>
          <a href="#pricing" className="text-sm">Pricing</a>
          <a href="#dashboard" className="text-sm">Dashboard</a>
          <a href="/dashboard" className="px-4 py-2 rounded-md bg-white shadow">Get API Key</a>
        </nav>
      </header>
      <main className="max-w-6xl mx-auto p-6 relative" style={{minHeight:400}}>
        <AnimatedBackground color='#004830' />
        <Hero primaryColor="#004830" creamColor="#7cafb0" />
        <Features />
        <section id="dashboard" className="mt-12">
          <h2 className="text-2xl font-bold mb-4">Dashboard preview</h2>
          <DashboardPreview />
        </section>
      </main>
      <Footer />
    </div>
  )
}

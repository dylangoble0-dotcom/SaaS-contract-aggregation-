import React from 'react'
const items = [
  {title:'High-quality leads', desc:'Targeted contract opportunities matched to your expertise.'},
  {title:'API-first', desc:'Integrate easily via REST API, webhooks, or SDK.'},
  {title:'Automated bid suggestions', desc:'AI-powered bid estimates to speed proposals.'},
]
export default function Features(){
  return (
    <section id="features" className="mt-10">
      <h3 className="text-2xl font-bold mb-6">Features</h3>
      <div className="grid md:grid-cols-3 gap-6">
        {items.map(i=>(
          <div key={i.title} className="p-6 rounded-lg bg-white shadow-sm">
            <h4 className="font-semibold mb-2">{i.title}</h4>
            <p className="text-sm text-gray-600">{i.desc}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
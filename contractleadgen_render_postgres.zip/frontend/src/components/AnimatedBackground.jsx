import React, {useRef, useEffect} from 'react'

export default function AnimatedBackground({color='#004830'}){
  const ref = useRef(null)

  useEffect(()=>{
    const canvas = ref.current
    const ctx = canvas.getContext('2d')
    let raf = null
    let width, height
    const DPR = window.devicePixelRatio || 1

    function resize(){
      width = canvas.clientWidth
      height = canvas.clientHeight
      canvas.width = Math.max(300, Math.floor(width * DPR))
      canvas.height = Math.max(200, Math.floor(height * DPR))
    }
    let t0 = 0

    function draw(time){
      if(!width || !height) resize()
      const t = (time - t0) / 1000
      ctx.clearRect(0,0,canvas.width,canvas.height)
      ctx.save()
      ctx.scale(DPR, DPR)

      // background gradient (cream overlay)
      const g = ctx.createLinearGradient(0,0,width, height)
      g.addColorStop(0, 'rgba(255,255,255,0.0)')
      g.addColorStop(1, 'rgba(255,255,255,0.0)')
      ctx.fillStyle = g
      ctx.fillRect(0,0,width, height)

      // draw multiple sine waves
      const waves = 4
      for(let i=0;i<waves;i++){
        const amplitude = 20 + 12*i
        const frequency = 0.008 + 0.002*i
        const speed = 0.6 + 0.2*i
        ctx.beginPath()
        for(let x=0;x<width;x+=2){
          const y = height*0.5 + Math.sin((x*frequency) + (t*speed) + i) * amplitude * (1 + 0.3*Math.sin(t+i))
          if(x===0) ctx.moveTo(x, y)
          else ctx.lineTo(x, y)
        }
        const alpha = 0.08 + 0.03*i
        ctx.strokeStyle = hexToRgba(color, alpha*(1 - i*0.1))
        ctx.lineWidth = 2 + i*0.6
        ctx.stroke()
      }

      // particles
      const count = 60
      for(let i=0;i<count;i++){
        const px = (i/count) * width + (Math.sin(t + i) * 30)
        const py = height*0.5 + Math.cos(t*0.6 + i) * (30 + 10*Math.sin(i))
        const size = 1 + (Math.sin(t + i) + 1)*0.8
        ctx.fillStyle = hexToRgba(color, 0.12)
        ctx.beginPath()
        ctx.arc(px, py, size, 0, Math.PI*2)
        ctx.fill()
      }

      ctx.restore()
      raf = requestAnimationFrame(draw)
    }

    function hexToRgba(hex, alpha){
      const h = hex.replace('#','')
      const bigint = parseInt(h,16)
      const r = (bigint >> 16) & 255
      const g = (bigint >> 8) & 255
      const b = bigint & 255
      return `rgba(${r}, ${g}, ${b}, ${alpha})`
    }

    function onResize(){ resize() }

    window.addEventListener('resize', onResize)
    resize()
    raf = requestAnimationFrame((t)=>{ t0 = t; draw(t) })

    return ()=>{
      window.removeEventListener('resize', onResize)
      if(raf) cancelAnimationFrame(raf)
    }
  },[ref])

  return <canvas ref={ref} style={{position:'absolute', inset:0, width:'100%', height:'100%', zIndex:-1}} aria-hidden />
}

import React from 'react'
export default function DashboardPreview(){
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="p-6 rounded-lg bg-white shadow">
        <h4 className="font-semibold mb-2">Your API Key</h4>
        <pre className="bg-gray-100 p-3 rounded">sk_live_xxx_... (demo)</pre>
        <p className="text-sm text-gray-600 mt-2">Rotate or revoke keys from the dashboard.</p>
      </div>
      <div className="p-6 rounded-lg bg-white shadow">
        <h4 className="font-semibold mb-2">Recent Leads</h4>
        <ul className="text-sm text-gray-700">
          <li>Roof replacement — Suggested: $5,200</li>
          <li>HVAC install — Suggested: $3,400</li>
          <li>Concrete pour — Suggested: $6,800</li>
        </ul>
      </div>
    </div>
  )
}
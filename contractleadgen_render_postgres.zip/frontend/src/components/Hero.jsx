import React from 'react'
export default function Hero({ primaryColor, creamColor }){
  return (
    <section className="grid lg:grid-cols-2 gap-8 items-center py-12 relative z-10">
      <div>
        <h2 className="text-4xl font-extrabold mb-4">Find contract leads. Win more bids.</h2>
        <p className="text-gray-700 mb-6">ContractLeadGen discovers bidding opportunities and delivers leads with suggested bids — integrate via API and start closing more work.</p>
        <div className="flex gap-3">
          <a className="px-5 py-3 rounded-md bg-primary text-white shadow">Get API Key</a>
          <a className="px-5 py-3 rounded-md border">See Docs</a>
        </div>
      </div>
      <div className="rounded-xl shadow-lg overflow-hidden" style={{background: 'linear-gradient(180deg, rgba(255,255,255,0.9), rgba(255,255,255,0.6))'}}>
        <div className="p-6 bg-white">
          <h3 className="text-lg font-semibold mb-2">Example lead</h3>
          <p className="text-sm text-gray-600">Roof replacement — 2000 sq ft</p>
          <div className="mt-4 p-4 rounded-md border">
            <div className="flex justify-between"><span className="text-sm">Suggested bid</span><strong>$5,200</strong></div>
            <div className="mt-3 text-xs text-gray-500">Delivered via API in JSON, CSV, or webhook</div>
          </div>
        </div>
      </div>
    </section>
  )
}
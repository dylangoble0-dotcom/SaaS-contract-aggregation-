# ContractLeadGen Frontend (Modern SaaS)

Primary color: #004830
Cream color: #7cafb0

Run:

1. npm install
2. npm run dev



## Production deployment (frontend)
The frontend builds via Vite and is served by nginx in the provided Dockerfile.
Set environment variables in `.env.production` before building, e.g.:
```
VITE_API_URL=https://yourdomain.com/api
VITE_STRIPE_PUBLISHABLE=pk_live_...
```

## Production deployment (backend)
- Ensure `DATABASE_URL` points to a production database (Postgres recommended).
- Set `ADMIN_TOKEN` to a long secret.
- Provide `STRIPE_SECRET` to enable checkout webhook handling.
- Use a Redis instance for rate limiting in production (replace in-memory limiter).

## TLS / Hosting
- Use a reverse proxy (Traefik / nginx) with TLS certificates (Let's Encrypt or your certs).
- Deploy backend and frontend containers to your cloud provider (DigitalOcean, AWS ECS, GCP, etc.).


# ContractLeadGen — Deploy to Render (Backend) + Vercel (Frontend)

This repository is prepared to deploy your backend to Render (using render.yaml) and frontend to Vercel.

## 1) Push to GitHub
Create a GitHub repo and push the entire repo (both /backend and /frontend).

## 2) Deploy Backend on Render (recommended)
1. Go to https://render.com and sign in.
2. In the Render dashboard, click "Create a new" → "Web Service" and choose "Deploy from a Git repo".
   - If you add the `render.yaml` to the repo, you can instead use "Infrastructure as Code" on Render to create services automatically.
3. If using `render.yaml` (recommended), go to Render → Infrastructure → Import from Repository → select `render.yaml` to create both the web service and the Postgres DB.
4. Add environment variables in Render (Dashboard → service → Environment):
   - `ADMIN_TOKEN` (a long random string)
   - `JWT_SECRET` (a long random string)
   - `STRIPE_SECRET` / `STRIPE_PUBLISHABLE` (your stripe keys)
   - `REDIS_URL` if you add a Redis service
5. Deploy. Render will build and start the backend. Note the backend public URL (e.g. https://contractleadgen-backend.onrender.com)

## 3) Deploy Frontend to Vercel
1. Go to https://vercel.com and sign in.
2. Click "New Project" → Import Git Repository (select the same GitHub repo).
3. For the project root, set the `frontend` directory.
4. Set build command: `npm run build` and output directory: `frontend/dist` (or configure as needed).
5. Add environment variable in Vercel: `VITE_API_URL=https://<your-backend-on-render>.onrender.com`
6. Deploy the site. Vercel will build and publish the frontend.
7. Update your DNS if you want a custom domain.

## 4) Stripe & Webhooks
- In Stripe dashboard, create a Checkout product/price and set up a webhook endpoint to `https://<your-backend>/stripe-webhook`.
- In your Render service, add `STRIPE_SECRET` and `STRIPE_PUBLISHABLE` env vars.
- Implement webhook signature verification in `backend/app/main.py` (there's a TODO placeholder).

## 5) Admin
- To issue an admin UI JWT, POST your `ADMIN_TOKEN` to `/admin/token` to receive a short-lived JWT for admin requests.

## 6) Postgres
- The `render.yaml` provisions a free Postgres instance (managed by Render). DATABASE_URL will be injected for your service automatically when using render.yaml.

## Local development
- Backend: create a virtualenv, install requirements, set DATABASE_URL to a local Postgres or sqlite file, and run `uvicorn app.main:app --reload`.
- Frontend: `cd frontend` → `npm install` → `npm run dev`

